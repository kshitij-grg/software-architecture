package service;

import java.math.BigDecimal;

public class TransferResult {

	private String status;
	private String message;
	private BigDecimal amount;
	private AccountBalance checking;
	private AccountBalance saving;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public AccountBalance getChecking() {
		return checking;
	}

	public void setChecking(AccountBalance checking) {
		this.checking = checking;
	}

	public AccountBalance getSaving() {
		return saving;
	}

	public void setSaving(AccountBalance saving) {
		this.saving = saving;
	}
}
