package service;

import java.math.BigDecimal;

public class TransferRequest {

	private String checkingAccountId;
	private String savingAccountId;
	private BigDecimal amount;
	private boolean simulateFailure;

	public String getCheckingAccountId() {
		return checkingAccountId;
	}

	public void setCheckingAccountId(String checkingAccountId) {
		this.checkingAccountId = checkingAccountId;
	}

	public String getSavingAccountId() {
		return savingAccountId;
	}

	public void setSavingAccountId(String savingAccountId) {
		this.savingAccountId = savingAccountId;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public boolean isSimulateFailure() {
		return simulateFailure;
	}

	public void setSimulateFailure(boolean simulateFailure) {
		this.simulateFailure = simulateFailure;
	}
}
