package service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.server.ResponseStatusException;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.net.URLEncoder;

@Service
public class TransferService {

	static final String COMMITTED = "COMMITTED";
	static final String ROLLED_BACK = "ROLLED_BACK";

	private final RestTemplate restTemplate;
	private final String checkingUrl;
	private final String savingUrl;

	public TransferService(RestTemplate restTemplate,
			@Value("${accounts.checking-url}") String checkingUrl,
			@Value("${accounts.saving-url}") String savingUrl) {
		this.restTemplate = restTemplate;
		this.checkingUrl = stripTrailingSlash(checkingUrl);
		this.savingUrl = stripTrailingSlash(savingUrl);
	}

	public TransferResult transfer(TransferRequest request) {
		requireText(request.getCheckingAccountId(), "checkingAccountId");
		requireText(request.getSavingAccountId(), "savingAccountId");
		if (request.getAmount() == null || request.getAmount().signum() <= 0) {
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Amount must be greater than zero");
		}

		String checkingId = request.getCheckingAccountId();
		String savingId = request.getSavingAccountId();
		getAccount(checkingUrl, checkingId);
		getAccount(savingUrl, savingId);

		boolean withdrawn = false;
		try {
			post(checkingUrl + "/accounts/" + encode(checkingId) + "/withdraw", request.getAmount());
			withdrawn = true;

			String depositUrl = savingUrl + "/accounts/" + encode(savingId) + "/deposit";
			if (request.isSimulateFailure()) {
				depositUrl = depositUrl + "?fail=true";
			}
			post(depositUrl, request.getAmount());

			return result(COMMITTED, "Transfer committed", request.getAmount(), checkingId, savingId);
		} catch (RuntimeException failure) {
			if (!withdrawn) {
				throw failure;
			}
			try {
				post(checkingUrl + "/accounts/" + encode(checkingId) + "/deposit", request.getAmount());
			} catch (RuntimeException compensationFailure) {
				throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
						"Deposit failed and the checking withdrawal could not be undone: "
								+ compensationFailure.getMessage());
			}
			return result(ROLLED_BACK,
					"Deposit failed (" + reason(failure) + "). Checking withdrawal was undone.",
					request.getAmount(), checkingId, savingId);
		}
	}

	private TransferResult result(String status, String message, BigDecimal amount, String checkingId, String savingId) {
		TransferResult result = new TransferResult();
		result.setStatus(status);
		result.setMessage(message);
		result.setAmount(amount);
		result.setChecking(getAccount(checkingUrl, checkingId));
		result.setSaving(getAccount(savingUrl, savingId));
		return result;
	}

	private AccountBalance getAccount(String baseUrl, String accountId) {
		try {
			return restTemplate.getForObject(baseUrl + "/accounts/" + encode(accountId), AccountBalance.class);
		} catch (HttpStatusCodeException ex) {
			throw downstream(ex);
		}
	}

	private void post(String url, BigDecimal amount) {
		try {
			restTemplate.postForObject(url, new AmountRequest(amount), AccountBalance.class);
		} catch (HttpStatusCodeException ex) {
			throw downstream(ex);
		}
	}

	private ResponseStatusException downstream(HttpStatusCodeException ex) {
		HttpStatus status = HttpStatus.resolve(ex.getRawStatusCode());
		if (status == null) {
			status = HttpStatus.BAD_GATEWAY;
		}
		String message = downstreamMessage(ex);
		return new ResponseStatusException(status, message);
	}

	private String downstreamMessage(HttpStatusCodeException ex) {
		String body = ex.getResponseBodyAsString();
		String marker = "\"message\":\"";
		if (body != null) {
			int start = body.indexOf(marker);
			if (start >= 0) {
				start = start + marker.length();
				int end = body.indexOf('"', start);
				if (end > start) {
					return body.substring(start, end);
				}
			}
		}
		if (ex.getStatusText() != null && !ex.getStatusText().isEmpty()) {
			return ex.getStatusText();
		}
		return "Account service call failed";
	}

	private String reason(RuntimeException failure) {
		if (failure instanceof ResponseStatusException) {
			String reason = ((ResponseStatusException) failure).getReason();
			if (reason != null && !reason.isEmpty()) {
				return reason;
			}
		}
		return failure.getMessage();
	}

	private void requireText(String value, String field) {
		if (value == null || value.trim().isEmpty()) {
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, field + " is required");
		}
	}

	private String encode(String value) {
		try {
			return URLEncoder.encode(value, "UTF-8");
		} catch (UnsupportedEncodingException ex) {
			throw new IllegalStateException(ex);
		}
	}

	private String stripTrailingSlash(String url) {
		if (url.endsWith("/")) {
			return url.substring(0, url.length() - 1);
		}
		return url;
	}
}
