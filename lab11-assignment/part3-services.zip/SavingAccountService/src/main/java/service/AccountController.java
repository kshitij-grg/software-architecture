package service;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

@RestController
public class AccountController {

	private final AccountStore accountStore;

	public AccountController(AccountStore accountStore) {
		this.accountStore = accountStore;
	}

	@PostMapping("/accounts")
	public ResponseEntity<Account> create(@RequestBody CreateAccountRequest request) {
		Account account = accountStore.create(request.getId(), request.getOwner(), request.getBalance());
		return ResponseEntity.status(HttpStatus.CREATED).body(account);
	}

	@GetMapping("/accounts/{id}")
	public Account get(@PathVariable String id) {
		return accountStore.get(id);
	}

	@PostMapping("/accounts/{id}/deposit")
	public Account deposit(@PathVariable String id,
			@RequestBody AmountRequest request,
			@RequestParam(name = "fail", defaultValue = "false") boolean fail) {
		if (fail) {
			throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Simulated deposit failure");
		}
		return accountStore.deposit(id, request.getAmount());
	}

	@PostMapping("/accounts/{id}/withdraw")
	public Account withdraw(@PathVariable String id, @RequestBody AmountRequest request) {
		return accountStore.withdraw(id, request.getAmount());
	}
}
