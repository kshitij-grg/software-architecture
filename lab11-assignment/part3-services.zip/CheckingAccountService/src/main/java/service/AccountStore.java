package service;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ResponseStatusException;

import java.math.BigDecimal;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Component
public class AccountStore {

	private final Map<String, Account> accounts = new ConcurrentHashMap<>();

	public Account create(String id, String owner, BigDecimal balance) {
		requireText(id, "id");
		requireText(owner, "owner");
		if (balance == null || balance.signum() < 0) {
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Opening balance cannot be negative");
		}
		Account created = new Account(id, owner, balance);
		if (accounts.putIfAbsent(id, created) != null) {
			throw new ResponseStatusException(HttpStatus.CONFLICT, "Account already exists: " + id);
		}
		return copy(created);
	}

	public Account get(String id) {
		return copy(require(id));
	}

	public Account deposit(String id, BigDecimal amount) {
		requirePositive(amount);
		Account[] updated = new Account[1];
		accounts.compute(id, (key, account) -> {
			if (account == null) {
				throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Account not found: " + id);
			}
			account.setBalance(account.getBalance().add(amount));
			updated[0] = copy(account);
			return account;
		});
		return updated[0];
	}

	public Account withdraw(String id, BigDecimal amount) {
		requirePositive(amount);
		Account[] updated = new Account[1];
		accounts.compute(id, (key, account) -> {
			if (account == null) {
				throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Account not found: " + id);
			}
			if (account.getBalance().compareTo(amount) < 0) {
				throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Insufficient funds");
			}
			account.setBalance(account.getBalance().subtract(amount));
			updated[0] = copy(account);
			return account;
		});
		return updated[0];
	}

	private Account require(String id) {
		Account account = accounts.get(id);
		if (account == null) {
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Account not found: " + id);
		}
		return account;
	}

	private void requireText(String value, String field) {
		if (value == null || value.trim().isEmpty()) {
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, field + " is required");
		}
	}

	private void requirePositive(BigDecimal amount) {
		if (amount == null || amount.signum() <= 0) {
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Amount must be greater than zero");
		}
	}

	private Account copy(Account account) {
		return new Account(account.getId(), account.getOwner(), account.getBalance());
	}
}
