package service;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class Controller {

	private final RestTemplate restTemplate;

	public Controller(RestTemplate restTemplate) {
		this.restTemplate = restTemplate;
	}

	@GetMapping("/productdata")
	public String getProductData() {
		return "Product: Laptop, Price: 1200";
	}

	@GetMapping("/phone")
	public String getPhone(
			@RequestHeader(HttpHeaders.AUTHORIZATION) String authorization) {

		return callService(
				"http://localhost:8091/phone",
				authorization
		);
	}

	@GetMapping("/salary")
	public String getSalary(
			@RequestHeader(HttpHeaders.AUTHORIZATION) String authorization) {

		return callService(
				"http://localhost:8092/salary",
				authorization
		);
	}

	private String callService(String url, String authorization) {
		HttpHeaders headers = new HttpHeaders();
		headers.set(HttpHeaders.AUTHORIZATION, authorization);

		HttpEntity<Void> request = new HttpEntity<>(headers);

		return restTemplate.exchange(
				url,
				HttpMethod.GET,
				request,
				String.class
		).getBody();
	}
}