package edu.miu.cs425.lab5webshop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab5WebshopApplicationTests {

    @Test
    void contextLoads() {
    }

}
