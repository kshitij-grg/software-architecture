package edu.miu.cs425.lab5webshop.service;

import edu.miu.cs425.lab5webshop.domain.CartItem;
import edu.miu.cs425.lab5webshop.domain.ShoppingCart;
import edu.miu.cs425.lab5webshop.repository.CartRepository;
import edu.miu.cs425.lab5webshop.repository.ProductRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.Optional;

@Service
public class CheckoutService {

    private final CartRepository cartRepository;
    private final ProductRepository productRepository;

    public CheckoutService(CartRepository cartRepository,
                           ProductRepository productRepository) {
        this.cartRepository = cartRepository;
        this.productRepository = productRepository;
    }

    public ShoppingCart addToShoppingCart(String cartId,
                                          String productNumber,
                                          int quantity) {
        if (quantity <= 0) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST, "Quantity must be greater than zero");
        }

        if (!productRepository.existsById(productNumber)) {
            throw new ResponseStatusException(
                    HttpStatus.NOT_FOUND, "Product not found: " + productNumber);
        }

        ShoppingCart cart = cartRepository.findById(cartId)
                .orElseGet(() -> new ShoppingCart(cartId));

        Optional<CartItem> existingItem = cart.getItems().stream()
                .filter(item -> item.getProductNumber().equals(productNumber))
                .findFirst();

        if (existingItem.isPresent()) {
            CartItem item = existingItem.get();
            item.setQuantity(item.getQuantity() + quantity);
        } else {
            cart.getItems().add(new CartItem(productNumber, quantity));
        }

        return cartRepository.save(cart);
    }

    public Optional<ShoppingCart> getShoppingCart(String cartId) {
        return cartRepository.findById(cartId);
    }
}