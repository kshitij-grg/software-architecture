package edu.miu.cs425.lab5webshop.controller;

public class AddCartItemRequest {

    private String productNumber;
    private int quantity;

    public AddCartItemRequest() {
    }

    public String getProductNumber() {
        return productNumber;
    }

    public void setProductNumber(String productNumber) {
        this.productNumber = productNumber;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
}