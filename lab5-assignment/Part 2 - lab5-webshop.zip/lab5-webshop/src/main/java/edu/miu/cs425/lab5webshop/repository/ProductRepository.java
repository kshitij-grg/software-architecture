package edu.miu.cs425.lab5webshop.repository;

import edu.miu.cs425.lab5webshop.domain.Product;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface ProductRepository extends MongoRepository<Product, String> {
}