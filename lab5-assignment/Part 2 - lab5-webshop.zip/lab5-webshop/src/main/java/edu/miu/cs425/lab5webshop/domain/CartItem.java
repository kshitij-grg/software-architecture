package edu.miu.cs425.lab5webshop.domain;

public class CartItem {

    private String productNumber;
    private int quantity;

    public CartItem() {
    }

    public CartItem(String productNumber, int quantity) {
        this.productNumber = productNumber;
        this.quantity = quantity;
    }

    public String getProductNumber() {
        return productNumber;
    }

    public void setProductNumber(String productNumber) {
        this.productNumber = productNumber;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
}