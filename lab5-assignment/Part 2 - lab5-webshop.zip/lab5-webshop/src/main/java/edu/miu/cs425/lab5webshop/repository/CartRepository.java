package edu.miu.cs425.lab5webshop.repository;

import edu.miu.cs425.lab5webshop.domain.ShoppingCart;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface CartRepository extends MongoRepository<ShoppingCart, String> {
}