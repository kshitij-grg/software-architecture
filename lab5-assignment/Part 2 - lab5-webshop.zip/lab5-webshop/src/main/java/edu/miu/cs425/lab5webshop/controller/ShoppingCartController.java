package edu.miu.cs425.lab5webshop.controller;

import edu.miu.cs425.lab5webshop.domain.ShoppingCart;
import edu.miu.cs425.lab5webshop.service.CheckoutService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/carts")
public class ShoppingCartController {

    private final CheckoutService checkoutService;

    public ShoppingCartController(CheckoutService checkoutService) {
        this.checkoutService = checkoutService;
    }

    @PostMapping("/{cartId}/items")
    public ResponseEntity<ShoppingCart> addToShoppingCart(
            @PathVariable String cartId,
            @RequestBody AddCartItemRequest request) {

        ShoppingCart savedCart = checkoutService.addToShoppingCart(
                cartId, request.getProductNumber(), request.getQuantity());

        return ResponseEntity.ok(savedCart);
    }

    @GetMapping("/{cartId}")
    public ResponseEntity<ShoppingCart> getShoppingCart(@PathVariable String cartId) {
        return checkoutService.getShoppingCart(cartId)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }
}