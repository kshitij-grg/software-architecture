package edu.miu.cs425.lab5webshop.client;

import edu.miu.cs425.lab5webshop.controller.AddCartItemRequest;
import edu.miu.cs425.lab5webshop.domain.CartItem;
import edu.miu.cs425.lab5webshop.domain.Product;
import edu.miu.cs425.lab5webshop.domain.ShoppingCart;
import org.springframework.http.MediaType;
import org.springframework.web.client.RestClient;

import java.math.BigDecimal;
import java.util.UUID;

public class WebshopRestClient {

    public static void main(String[] args) {
        RestClient client = RestClient.builder()
                .baseUrl("http://localhost:8080")
                .build();

        String productNumber = "P-" + UUID.randomUUID().toString().substring(0, 8);
        String cartId = "CART-" + UUID.randomUUID().toString().substring(0, 8);

        // 1. Add a product through the REST API.
        Product newProduct = new Product(
                productNumber,
                "Wireless Mouse",
                new BigDecimal("29.99")
        );

        client.post()
                .uri("/api/products")
                .contentType(MediaType.APPLICATION_JSON)
                .body(newProduct)
                .retrieve()
                .toBodilessEntity();

        // 2. Get the product through the REST API and print it.
        Product retrievedProduct = client.get()
                .uri("/api/products/{productNumber}", productNumber)
                .retrieve()
                .body(Product.class);

        if (retrievedProduct == null) {
            throw new IllegalStateException("Product response was empty");
        }

        System.out.println("Retrieved product:");
        System.out.println("Product number: " + retrievedProduct.getProductNumber());
        System.out.println("Description: " + retrievedProduct.getDescription());
        System.out.println("Price: " + retrievedProduct.getPrice());

        // 3. Add the retrieved product to a cart through the REST API.
        AddCartItemRequest itemRequest = new AddCartItemRequest();
        itemRequest.setProductNumber(retrievedProduct.getProductNumber());
        itemRequest.setQuantity(2);

        client.post()
                .uri("/api/carts/{cartId}/items", cartId)
                .contentType(MediaType.APPLICATION_JSON)
                .body(itemRequest)
                .retrieve()
                .toBodilessEntity();

        // 4. Get the cart through the REST API and print it.
        ShoppingCart retrievedCart = client.get()
                .uri("/api/carts/{cartId}", cartId)
                .retrieve()
                .body(ShoppingCart.class);

        if (retrievedCart == null) {
            throw new IllegalStateException("Shopping cart response was empty");
        }

        System.out.println("\nRetrieved shopping cart:");
        System.out.println("Cart ID: " + retrievedCart.getCartId());

        for (CartItem item : retrievedCart.getItems()) {
            System.out.println("Product number: " + item.getProductNumber()
                    + ", quantity: " + item.getQuantity());
        }
    }
}