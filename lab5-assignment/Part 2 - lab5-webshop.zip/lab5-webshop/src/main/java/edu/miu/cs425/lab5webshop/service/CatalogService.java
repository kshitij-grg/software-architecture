package edu.miu.cs425.lab5webshop.service;

import edu.miu.cs425.lab5webshop.domain.Product;
import edu.miu.cs425.lab5webshop.repository.ProductRepository;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class CatalogService {

    private final ProductRepository productRepository;

    public CatalogService(ProductRepository productRepository) {
        this.productRepository = productRepository;
    }

    public Product addProduct(Product product) {
        return productRepository.save(product);
    }

    public Optional<Product> getProduct(String productNumber) {
        return productRepository.findById(productNumber);
    }
}