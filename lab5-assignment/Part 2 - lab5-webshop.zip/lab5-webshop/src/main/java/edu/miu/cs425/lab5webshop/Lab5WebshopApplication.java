package edu.miu.cs425.lab5webshop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab5WebshopApplication {

    public static void main(String[] args) {
        SpringApplication.run(Lab5WebshopApplication.class, args);
    }

}
