package app.repositories;

import app.domain.Student;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface StudentRepository extends JpaRepository<Student, Long> {

    List<Student> findByName(String name);

    Optional<Student> findByPhoneNumber(String phoneNumber);

    List<Student> findByAddressCity(String city);
}