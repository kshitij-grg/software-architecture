package students.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import students.domain.Student;

import java.util.List;
import java.util.Optional;

public interface StudentRepository extends MongoRepository<Student, String> {

    List<Student> findByName(String name);

    Optional<Student> findByPhoneNumber(String phoneNumber);

    List<Student> findByAddressCity(String city);
}