package students;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import students.domain.Address;
import students.domain.Student;
import students.repository.StudentRepository;

@SpringBootApplication
public class StudentApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentApplication.class, args);
	}

	@Bean
	CommandLineRunner run(StudentRepository studentRepository) {
		return args -> {

			studentRepository.deleteAll();

			studentRepository.save(new Student(
					"John Smith",
					"314-555-1001",
					"john.smith@example.com",
					new Address("100 Main Street", "St. Louis", "63101")
			));

			studentRepository.save(new Student(
					"Maria Garcia",
					"314-555-1002",
					"maria.garcia@example.com",
					new Address("250 Olive Boulevard", "Olivette", "63132")
			));

			studentRepository.save(new Student(
					"John Smith",
					"314-555-1003",
					"john.smith2@example.com",
					new Address("45 Market Street", "St. Louis", "63102")
			));

			studentRepository.save(new Student(
					"Aisha Khan",
					"314-555-1004",
					"aisha.khan@example.com",
					new Address("700 Westwood Drive", "Olivette", "63132")
			));

			studentRepository.save(new Student(
					"David Lee",
					"314-555-1005",
					"david.lee@example.com",
					new Address("82 Grand Avenue", "Chicago", "60601")
			));

			System.out.println("\n========== 1. ALL STUDENTS ==========");
			studentRepository.findAll()
					.forEach(System.out::println);

			System.out.println("\n========== 2. STUDENTS NAMED JOHN SMITH ==========");
			studentRepository.findByName("John Smith")
					.forEach(System.out::println);

			System.out.println("\n========== 3. STUDENT WITH PHONE NUMBER 314-555-1003 ==========");
			studentRepository.findByPhoneNumber("314-555-1003")
					.ifPresentOrElse(
							System.out::println,
							() -> System.out.println("Student not found")
					);

			System.out.println("\n========== 4. STUDENTS FROM OLIVETTE ==========");
			studentRepository.findByAddressCity("Olivette")
					.forEach(System.out::println);
		};
	}
}