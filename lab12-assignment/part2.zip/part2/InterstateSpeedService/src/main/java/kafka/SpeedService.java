package kafka;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
public class SpeedService {

    private final Map<String, SensorRecord> camera1Records =
            new HashMap<>();

    private final Map<String, SensorRecord> camera2Records =
            new HashMap<>();

    @Autowired
    private KafkaTemplate<String, Object> kafkaTemplate;

    @KafkaListener(
        topics = {"cameratopic1", "cameratopic2"},
        groupId = "speed-service-v1"
    )
    public synchronized void receive(SensorRecord record)
            throws Exception {

        if (record.licencePlate == null
                || record.minute < 0 || record.minute > 59
                || record.second < 0 || record.second > 59) {
            System.err.println("Ignoring invalid camera record");
            return;
        }

        if (record.cameraId == 1) {
            camera1Records.put(record.licencePlate, record);
        } else if (record.cameraId == 2) {
            camera2Records.put(record.licencePlate, record);
        } else {
            System.err.println("Ignoring unknown camera ID");
            return;
        }

        SensorRecord first =
                camera1Records.get(record.licencePlate);

        SensorRecord second =
                camera2Records.get(record.licencePlate);

        if (first == null || second == null) {
            return;
        }

        int firstTime = first.minute * 60 + first.second;
        int secondTime = second.minute * 60 + second.second;

        int elapsedSeconds =
                (secondTime - firstTime + 3600) % 3600;

        if (elapsedSeconds == 0) {
            camera1Records.remove(record.licencePlate);
            camera2Records.remove(record.licencePlate);

            System.err.println(
                "Cannot calculate speed: zero elapsed time for "
                + record.licencePlate
            );
            return;
        }

        double speed = 1800.0 / elapsedSeconds;

        System.out.printf(
            "Plate: %s | Time: %d seconds | Speed: %.2f mph%n",
            record.licencePlate,
            elapsedSeconds,
            speed
        );

        if (speed > 72.0) {
            SpeedRecord result =
                    new SpeedRecord(record.licencePlate, speed);

            kafkaTemplate.send(
                "tofasttopic",
                record.licencePlate,
                result
            ).get(10, TimeUnit.SECONDS);

            System.out.println(
                "Published speeding vehicle: "
                + record.licencePlate
            );
        }

        camera1Records.remove(record.licencePlate);
        camera2Records.remove(record.licencePlate);
    }
}