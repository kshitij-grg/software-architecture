package kafka;

public class SpeedRecord {

    public String licencePlate;
    public double speed;

    public SpeedRecord() {
    }

    public SpeedRecord(String licencePlate, double speed) {
        this.licencePlate = licencePlate;
        this.speed = speed;
    }
}