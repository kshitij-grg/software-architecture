package kafka;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Service;

@Service
public class OwnerRegistry {

    private final Map<String, Owner> owners = new HashMap<>();

    public OwnerRegistry() {
        String[] prefixes = {
            "AA", "GA", "FB", "BB", "FF", "FG",
            "CC", "EE", "FA", "AS", "GS", "FBS",
            "BS", "FS", "FGS", "CS", "ES", "FAS"
        };

        for (String prefix : prefixes) {
            for (int number = 1000; number < 2000; number++) {
                String plate = prefix + number;

                owners.put(
                    plate,
                    new Owner(
                        "Demo Owner " + plate,
                        number + " Example Street, Demo City"
                    )
                );
            }
        }
    }

    public Owner findByPlate(String licencePlate) {
        return owners.get(licencePlate);
    }

    public static class Owner {

        public final String name;
        public final String address;

        public Owner(String name, String address) {
            this.name = name;
            this.address = address;
        }
    }
}