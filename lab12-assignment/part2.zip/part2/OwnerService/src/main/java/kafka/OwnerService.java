package kafka;

import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
public class OwnerService {

    @Autowired
    private OwnerRegistry ownerRegistry;

    @Autowired
    private KafkaTemplate<String, Object> kafkaTemplate;

    @KafkaListener(
        topics = "tofasttopic",
        groupId = "owner-service-v1"
    )
    public void receive(SpeedRecord record) throws Exception {

        if (record.licencePlate == null
                || Double.isNaN(record.speed)
                || Double.isInfinite(record.speed)
                || record.speed <= 72.0) {
            System.err.println("Ignoring invalid/non-speeding record");
            return;
        }

        OwnerRegistry.Owner owner =
                ownerRegistry.findByPlate(record.licencePlate);

        if (owner == null) {
            System.err.println(
                "Owner not found for plate: " + record.licencePlate
            );
            return;
        }

        FeeRecord result = new FeeRecord(
            record.licencePlate,
            record.speed,
            owner.name,
            owner.address
        );

        kafkaTemplate.send(
            "ownertopic",
            record.licencePlate,
            result
        ).get(10, TimeUnit.SECONDS);

        System.out.printf(
            "Plate: %s | Owner: %s | Address: %s | Speed: %.2f mph%n",
            result.licencePlate,
            result.ownerName,
            result.ownerAddress,
            result.speed
        );
    }
}