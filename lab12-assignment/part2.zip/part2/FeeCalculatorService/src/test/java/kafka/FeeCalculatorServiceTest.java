package kafka;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class FeeCalculatorServiceTest {

    private final FeeCalculatorService service =
            new FeeCalculatorService();

    @Test
    public void calculatesFeesAtBoundaries() {
        assertEquals(0, service.calculateFee(72.0));

        assertEquals(25, service.calculateFee(72.01));
        assertEquals(25, service.calculateFee(77.0));

        assertEquals(45, service.calculateFee(77.01));
        assertEquals(45, service.calculateFee(82.0));

        assertEquals(80, service.calculateFee(82.01));
        assertEquals(80, service.calculateFee(90.0));

        assertEquals(125, service.calculateFee(90.01));
    }
}