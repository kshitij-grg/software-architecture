package kafka;

public class FeeRecord {

    public String licencePlate;
    public double speed;
    public String ownerName;
    public String ownerAddress;

    public FeeRecord() {
    }

    public FeeRecord(
            String licencePlate,
            double speed,
            String ownerName,
            String ownerAddress) {

        this.licencePlate = licencePlate;
        this.speed = speed;
        this.ownerName = ownerName;
        this.ownerAddress = ownerAddress;
    }
}