package kafka;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.kafka.annotation.EnableKafka;

@SpringBootApplication
@EnableKafka
public class FeeCalculatorApplication {

    public static void main(String[] args) {
        SpringApplication.run(FeeCalculatorApplication.class, args);
    }
}