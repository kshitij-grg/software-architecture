package kafka;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
public class FeeCalculatorService {

    public int calculateFee(double speed) {
        if (Double.isNaN(speed) || Double.isInfinite(speed)) {
            throw new IllegalArgumentException("Speed must be finite");
        }

        if (speed <= 72.0) {
            return 0;
        }

        if (speed <= 77.0) {
            return 25;
        }

        if (speed <= 82.0) {
            return 45;
        }

        if (speed <= 90.0) {
            return 80;
        }

        return 125;
    }

    @KafkaListener(
        topics = "ownertopic",
        groupId = "fee-calculator-service-v1"
    )
    public void receive(FeeRecord record) {

        if (record == null
                || record.licencePlate == null
                || record.ownerName == null
                || record.ownerAddress == null
                || Double.isNaN(record.speed)
                || Double.isInfinite(record.speed)
                || record.speed <= 72.0) {

            System.err.println(
                "Ignoring invalid or non-speeding fee record"
            );
            return;
        }

        int fee = calculateFee(record.speed);

        System.out.printf(
            "Plate: %s | Owner: %s | Address: %s"
                + " | Speed: %.2f mph | Fine: $%d%n",
            record.licencePlate,
            record.ownerName,
            record.ownerAddress,
            record.speed,
            fee
        );
    }
}