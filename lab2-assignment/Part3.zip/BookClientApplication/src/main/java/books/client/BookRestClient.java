package books.client;

import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.math.BigDecimal;
import java.util.List;

@Component
public class BookRestClient {

    private static final String BASE_URL = "http://localhost:8080/books";

    private final RestTemplate restTemplate;

    public BookRestClient(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public void runDemo() {

        Book book = new Book(
                "9780132350884",
                "Robert C. Martin",
                "Clean Code",
                new BigDecimal("42.99")
        );

        // 1. Add a book: POST /books
        Book addedBook = restTemplate.postForObject(
                BASE_URL,
                book,
                Book.class
        );
        System.out.println("Added book: " + addedBook);

        // 2. Get one book: GET /books/{isbn}
        Book foundBook = restTemplate.getForObject(
                BASE_URL + "/{isbn}",
                Book.class,
                book.getIsbn()
        );
        System.out.println("Retrieved book: " + foundBook);

        // 3. Update book: PUT /books/{isbn}
        foundBook.setTitle("Clean Code: A Handbook of Agile Software Craftsmanship");
        foundBook.setPrice(new BigDecimal("45.99"));

        ResponseEntity<Book> updatedResponse = restTemplate.exchange(
                BASE_URL + "/{isbn}",
                HttpMethod.PUT,
                new HttpEntity<>(foundBook),
                Book.class,
                foundBook.getIsbn()
        );
        System.out.println("Updated book: " + updatedResponse.getBody());

        // 4. Get all books: GET /books
        ResponseEntity<List<Book>> allBooksResponse = restTemplate.exchange(
                BASE_URL,
                HttpMethod.GET,
                null,
                new ParameterizedTypeReference<List<Book>>() {
                }
        );
        System.out.println("All books: " + allBooksResponse.getBody());

        // 5. Delete a book: DELETE /books/{isbn}
        restTemplate.delete(
                BASE_URL + "/{isbn}",
                foundBook.getIsbn()
        );
        System.out.println("Deleted book with ISBN: " + foundBook.getIsbn());
    }
}