package books.model;

public class BookEvent {

    private String action;
    private Book book;

    public BookEvent() {
    }

    public BookEvent(String action, Book book) {
        this.action = action;
        this.book = book;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public Book getBook() {
        return book;
    }

    public void setBook(Book book) {
        this.book = book;
    }

    @Override
    public String toString() {
        return "BookEvent{" +
                "action='" + action + '\'' +
                ", book=" + book +
                '}';
    }
}