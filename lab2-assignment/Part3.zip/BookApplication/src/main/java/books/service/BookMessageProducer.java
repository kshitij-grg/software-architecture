package books.service;

import books.model.Book;
import books.model.BookEvent;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Service;

@Service
public class BookMessageProducer {

    private final JmsTemplate jmsTemplate;
    private final String queueName;

    public BookMessageProducer(
            JmsTemplate jmsTemplate,
            @Value("${book.queue.name}") String queueName
    ) {
        this.jmsTemplate = jmsTemplate;
        this.queueName = queueName;
    }

    public void sendBookEvent(String action, Book book) {
        BookEvent event = new BookEvent(action, book);

        jmsTemplate.convertAndSend(queueName, event);

        System.out.println("Sent JMS message: " + event);
    }
}