package books.service;

import books.model.Book;
import books.repository.BookRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@Service
public class BookService {

    private final BookRepository bookRepository;
    private final BookMessageProducer bookMessageProducer;

    public BookService(
            BookRepository bookRepository,
            BookMessageProducer bookMessageProducer
    ) {
        this.bookRepository = bookRepository;
        this.bookMessageProducer = bookMessageProducer;
    }

    public Book addBook(Book book) {
        if (bookRepository.existsByIsbn(book.getIsbn())) {
            throw new ResponseStatusException(
                    HttpStatus.CONFLICT,
                    "A book with ISBN " + book.getIsbn() + " already exists"
            );
        }

        Book savedBook = bookRepository.save(book);

        bookMessageProducer.sendBookEvent("ADDED", savedBook);

        return savedBook;
    }

    public Book updateBook(Book book) {
        if (!bookRepository.existsByIsbn(book.getIsbn())) {
            throw new ResponseStatusException(
                    HttpStatus.NOT_FOUND,
                    "Book with ISBN " + book.getIsbn() + " was not found"
            );
        }

        Book updatedBook = bookRepository.save(book);

        bookMessageProducer.sendBookEvent("UPDATED", updatedBook);

        return updatedBook;
    }

    public Book getBook(String isbn) {
        return bookRepository.findByIsbn(isbn)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        "Book with ISBN " + isbn + " was not found"
                ));
    }

    public List<Book> getAllBooks() {
        return bookRepository.findAll();
    }

    public Book deleteBook(String isbn) {
        Book deletedBook = bookRepository.deleteByIsbn(isbn)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        "Book with ISBN " + isbn + " was not found"
                ));

        bookMessageProducer.sendBookEvent("DELETED", deletedBook);

        return deletedBook;
    }
}