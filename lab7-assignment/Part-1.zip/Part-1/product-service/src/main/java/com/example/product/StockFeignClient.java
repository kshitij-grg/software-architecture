package com.example.product;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(
        name = "StockService",
        url = "http://localhost:8900"
)
public interface StockFeignClient {

    @GetMapping("/stock/{productNumber}")
    int getStock(@PathVariable("productNumber") String productNumber);
}
