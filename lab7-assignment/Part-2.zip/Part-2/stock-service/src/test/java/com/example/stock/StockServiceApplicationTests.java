package com.example.stock;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StockServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
