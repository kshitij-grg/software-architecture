package edu.miu.cs425.lab5webshop.dto;

import java.math.BigDecimal;

public record PriceUpdateRequest(BigDecimal price) {
}