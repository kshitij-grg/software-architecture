package edu.miu.cs425.lab5webshop.integration;

import edu.miu.cs425.lab5webshop.dto.PriceUpdateRequest;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient(name = "Shoppingcartservice")
public interface ShoppingCartFeignClient {

    @PutMapping("/internal/cart-items/{productNumber}/price")
    void updateProductPrice(
            @PathVariable("productNumber") String productNumber,
            @RequestBody PriceUpdateRequest request);
}