package edu.miu.cs425.lab5webshop.service;

import edu.miu.cs425.lab5webshop.domain.Product;
import edu.miu.cs425.lab5webshop.dto.PriceUpdateRequest;
import edu.miu.cs425.lab5webshop.integration.ShoppingCartFeignClient;
import edu.miu.cs425.lab5webshop.repository.ProductRepository;
import feign.FeignException;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.math.BigDecimal;
import java.util.Optional;

@Service
public class CatalogService {

    private final ProductRepository productRepository;
    private final ShoppingCartFeignClient shoppingCartClient;

    public CatalogService(
            ProductRepository productRepository,
            ShoppingCartFeignClient shoppingCartClient) {

        this.productRepository = productRepository;
        this.shoppingCartClient = shoppingCartClient;
    }

    public Product addProduct(Product product) {
        return productRepository.save(product);
    }

    public Optional<Product> getProduct(String productNumber) {
        return productRepository.findById(productNumber);
    }

    public Product updatePrice(
            String productNumber,
            BigDecimal price) {

        if (price == null || price.signum() < 0) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Price must be provided and cannot be negative"
            );
        }

        Product product = productRepository.findById(productNumber)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        "Product not found: " + productNumber
                ));

        product.setPrice(price);
        Product saved = productRepository.save(product);

        try {
            shoppingCartClient.updateProductPrice(
                    productNumber,
                    new PriceUpdateRequest(price)
            );
        } catch (FeignException ex) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_GATEWAY,
                    "Product price saved, but cart synchronization failed. "
                            + "Retry the same price update.",
                    ex
            );
        }

        return saved;
    }
}