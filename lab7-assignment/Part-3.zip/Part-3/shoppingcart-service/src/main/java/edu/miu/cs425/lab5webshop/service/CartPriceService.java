package edu.miu.cs425.lab5webshop.service;

import edu.miu.cs425.lab5webshop.domain.ShoppingCart;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;

@Service
public class CartPriceService {

    private final MongoTemplate mongoTemplate;

    public CartPriceService(MongoTemplate mongoTemplate) {
        this.mongoTemplate = mongoTemplate;
    }

    public void updateProductPrice(
            String productNumber,
            BigDecimal price) {

        Query query = Query.query(
                Criteria.where("items.productNumber")
                        .is(productNumber)
        );

        Update update = new Update()
                .set("items.$[item].price", price)
                .filterArray(
                        Criteria.where("item.productNumber")
                                .is(productNumber)
                );

        mongoTemplate.updateMulti(
                query,
                update,
                ShoppingCart.class
        );
    }
}