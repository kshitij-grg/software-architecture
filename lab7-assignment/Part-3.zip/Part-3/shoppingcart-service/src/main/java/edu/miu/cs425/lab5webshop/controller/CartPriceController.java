package edu.miu.cs425.lab5webshop.controller;

import edu.miu.cs425.lab5webshop.dto.PriceUpdateRequest;
import edu.miu.cs425.lab5webshop.service.CartPriceService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

@RestController
@RequestMapping("/internal/cart-items")
public class CartPriceController {

    private final CartPriceService cartPriceService;

    public CartPriceController(CartPriceService cartPriceService) {
        this.cartPriceService = cartPriceService;
    }

    @PutMapping("/{productNumber}/price")
    public ResponseEntity<Void> updateProductPrice(
            @PathVariable("productNumber") String productNumber,
            @RequestBody PriceUpdateRequest request) {

        if (request.price() == null
                || request.price().signum() < 0) {

            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Price must be provided and cannot be negative"
            );
        }

        cartPriceService.updateProductPrice(
                productNumber,
                request.price()
        );

        return ResponseEntity.noContent().build();
    }
}