package edu.miu.cs425.lab5webshop.integration;

import edu.miu.cs425.lab5webshop.dto.ProductResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "Productservice")
public interface ProductFeignClient {

    @GetMapping("/api/products/{productNumber}")
    ProductResponse getProduct(
            @PathVariable("productNumber") String productNumber);
}