package edu.miu.cs425.lab5webshop.service;

import edu.miu.cs425.lab5webshop.domain.CartItem;
import edu.miu.cs425.lab5webshop.domain.ShoppingCart;
import edu.miu.cs425.lab5webshop.dto.ProductResponse;
import edu.miu.cs425.lab5webshop.integration.ProductFeignClient;
import edu.miu.cs425.lab5webshop.repository.CartRepository;
import feign.FeignException;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.Optional;

@Service
public class CheckoutService {

    private final CartRepository cartRepository;
    private final ProductFeignClient productClient;

    public CheckoutService(
            CartRepository cartRepository,
            ProductFeignClient productClient) {

        this.cartRepository = cartRepository;
        this.productClient = productClient;
    }

    public ShoppingCart addToShoppingCart(
            String cartId,
            String productNumber,
            int quantity) {

        if (quantity <= 0) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Quantity must be greater than zero"
            );
        }

        ProductResponse product;

        try {
            product = productClient.getProduct(productNumber);
        } catch (FeignException.NotFound ex) {
            throw new ResponseStatusException(
                    HttpStatus.NOT_FOUND,
                    "Product not found: " + productNumber,
                    ex
            );
        } catch (FeignException ex) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_GATEWAY,
                    "Could not retrieve product data",
                    ex
            );
        }

        if (product == null) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_GATEWAY,
                    "Product service returned an empty response"
            );
        }

        ShoppingCart cart = cartRepository.findById(cartId)
                .orElseGet(() -> new ShoppingCart(cartId));

        Optional<CartItem> existingItem = cart.getItems().stream()
                .filter(item ->
                        item.getProductNumber().equals(productNumber))
                .findFirst();

        if (existingItem.isPresent()) {
            CartItem item = existingItem.get();
            item.setQuantity(item.getQuantity() + quantity);
            item.setDescription(product.description());
            item.setPrice(product.price());
        } else {
            cart.getItems().add(new CartItem(
                    product.productNumber(),
                    product.description(),
                    product.price(),
                    quantity
            ));
        }

        return cartRepository.save(cart);
    }

    public Optional<ShoppingCart> getShoppingCart(String cartId) {
        return cartRepository.findById(cartId);
    }
}