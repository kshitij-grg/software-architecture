package edu.miu.cs425.lab7client;

import org.springframework.http.MediaType;
import org.springframework.web.client.RestClient;

import java.math.BigDecimal;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

public class WebshopRestClient {

    public record ProductResponse(
            String productNumber,
            String description,
            BigDecimal price) {
    }

    public record AddCartItemRequest(
            String productNumber,
            int quantity) {
    }

    public record PriceUpdateRequest(BigDecimal price) {
    }

    public record CartItemResponse(
            String productNumber,
            String description,
            BigDecimal price,
            int quantity) {
    }

    public record ShoppingCartResponse(
            String cartId,
            List<CartItemResponse> items) {
    }

    public static void main(String[] args) {

        RestClient productClient = RestClient.builder()
                .baseUrl("http://localhost:8910")
                .build();

        RestClient cartClient = RestClient.builder()
                .baseUrl("http://localhost:8911")
                .build();

        String suffix = UUID.randomUUID().toString();

        String productNumber = "P-" + suffix;
        String cart1Id = "CART1-" + suffix;
        String cart2Id = "CART2-" + suffix;

        BigDecimal originalPrice = new BigDecimal("29.99");
        BigDecimal updatedPrice = new BigDecimal("39.99");

        // 1. Create a product.
        ProductResponse newProduct = new ProductResponse(
                productNumber,
                "Wireless Mouse",
                originalPrice
        );

        productClient.post()
                .uri("/api/products")
                .contentType(MediaType.APPLICATION_JSON)
                .body(newProduct)
                .retrieve()
                .toBodilessEntity();

        // 2. Retrieve and print the product.
        ProductResponse retrievedProduct = Objects.requireNonNull(
                productClient.get()
                        .uri("/api/products/{productNumber}", productNumber)
                        .retrieve()
                        .body(ProductResponse.class),
                "Product response was empty"
        );

        System.out.println("Created product:");
        System.out.println("Product number: "
                + retrievedProduct.productNumber());
        System.out.println("Description: "
                + retrievedProduct.description());
        System.out.println("Price: "
                + retrievedProduct.price());

        // 3. Add the product to two carts.
        addToCart(cartClient, cart1Id, productNumber, 2);
        addToCart(cartClient, cart2Id, productNumber, 1);

        // 4. Retrieve and verify the original cart prices.
        ShoppingCartResponse before1 = getCart(cartClient, cart1Id);
        ShoppingCartResponse before2 = getCart(cartClient, cart2Id);

        verifyCart(before1, productNumber, originalPrice, 2);
        verifyCart(before2, productNumber, originalPrice, 1);

        System.out.println("\nBefore price update:");
        printCart(before1);
        printCart(before2);

        // 5. Update only ProductService.
        ProductResponse updatedProduct = Objects.requireNonNull(
                productClient.put()
                        .uri(
                                "/api/products/{productNumber}/price",
                                productNumber
                        )
                        .contentType(MediaType.APPLICATION_JSON)
                        .body(new PriceUpdateRequest(updatedPrice))
                        .retrieve()
                        .body(ProductResponse.class),
                "Price-update response was empty"
        );

        if (updatedProduct.price() == null
                || updatedProduct.price().compareTo(updatedPrice) != 0) {

            throw new IllegalStateException(
                    "ProductService did not return the updated price"
            );
        }

        // 6. Retrieve carts without re-adding the product.
        ShoppingCartResponse after1 = getCart(cartClient, cart1Id);
        ShoppingCartResponse after2 = getCart(cartClient, cart2Id);

        verifyCart(after1, productNumber, updatedPrice, 2);
        verifyCart(after2, productNumber, updatedPrice, 1);

        System.out.println("\nAfter price update:");
        System.out.println("Product price: " + updatedProduct.price());
        printCart(after1);
        printCart(after2);

        System.out.println(
                "\nPASS: Both carts received the updated price "
                        + "and their quantities stayed unchanged."
        );
    }

    private static void addToCart(
            RestClient client,
            String cartId,
            String productNumber,
            int quantity) {

        client.post()
                .uri("/api/carts/{cartId}/items", cartId)
                .contentType(MediaType.APPLICATION_JSON)
                .body(new AddCartItemRequest(productNumber, quantity))
                .retrieve()
                .toBodilessEntity();
    }

    private static ShoppingCartResponse getCart(
            RestClient client,
            String cartId) {

        return Objects.requireNonNull(
                client.get()
                        .uri("/api/carts/{cartId}", cartId)
                        .retrieve()
                        .body(ShoppingCartResponse.class),
                "Cart response was empty"
        );
    }

    private static void printCart(ShoppingCartResponse cart) {

        System.out.println("Cart ID: " + cart.cartId());

        for (CartItemResponse item : cart.items()) {
            System.out.println(
                    "  Product: " + item.productNumber()
                            + ", description: " + item.description()
                            + ", unit price: " + item.price()
                            + ", quantity: " + item.quantity()
            );
        }
    }

    private static void verifyCart(
            ShoppingCartResponse cart,
            String productNumber,
            BigDecimal expectedPrice,
            int expectedQuantity) {

        CartItemResponse item = cart.items().stream()
                .filter(entry ->
                        productNumber.equals(entry.productNumber()))
                .findFirst()
                .orElseThrow(() -> new IllegalStateException(
                        "Product missing from cart " + cart.cartId()
                ));

        if (item.price() == null
                || item.price().compareTo(expectedPrice) != 0
                || item.quantity() != expectedQuantity) {

            throw new IllegalStateException(
                    "Unexpected price or quantity in cart " + cart.cartId()
            );
        }
    }
}