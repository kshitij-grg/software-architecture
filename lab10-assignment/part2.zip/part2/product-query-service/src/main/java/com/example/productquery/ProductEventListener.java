package com.example.productquery;

import com.example.events.ProductEvent;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

@Component
public class ProductEventListener {

    private final ProductViewRepository repository;

    public ProductEventListener(ProductViewRepository repository) {
        this.repository = repository;
    }

    @RabbitListener(queues = RabbitConfig.QUEUE)
    public void handle(ProductEvent event) {
        switch (event.eventType()) {
            case "PRODUCT_CREATED", "PRODUCT_UPDATED" -> {
                ProductView view = getOrCreate(event.productNumber());

                view.setName(event.name());
                view.setPrice(event.price());

                repository.save(view);
            }

            case "PRODUCT_DELETED" ->
                    repository.deleteById(event.productNumber());

            case "STOCK_UPDATED" -> {
                ProductView view = getOrCreate(event.productNumber());

                view.setNumberInStock(event.quantity());

                repository.save(view);
            }

            case "STOCK_DELETED" ->
                    repository.findById(event.productNumber())
                            .ifPresent(view -> {
                                view.setNumberInStock(0);
                                repository.save(view);
                            });

            default -> throw new IllegalArgumentException(
                    "Unknown event type: " + event.eventType());
        }
    }

    private ProductView getOrCreate(String productNumber) {
        return repository.findById(productNumber)
                .orElseGet(() -> {
                    ProductView view = new ProductView();
                    view.setProductNumber(productNumber);
                    return view;
                });
    }
}