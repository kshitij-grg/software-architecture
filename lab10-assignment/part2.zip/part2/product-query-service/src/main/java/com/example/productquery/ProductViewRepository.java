package com.example.productquery;

import org.springframework.data.mongodb.repository.MongoRepository;

public interface ProductViewRepository
        extends MongoRepository<ProductView, String> {
}