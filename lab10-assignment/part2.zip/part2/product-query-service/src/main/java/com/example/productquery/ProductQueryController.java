package com.example.productquery;

import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

@RestController
@RequestMapping("/products")
public class ProductQueryController {

    private final ProductViewRepository repository;

    public ProductQueryController(ProductViewRepository repository) {
        this.repository = repository;
    }

    @GetMapping
    public List<ProductView> getAll() {
        return repository.findAll().stream()
                .filter(view -> view.getName() != null
                        && view.getPrice() != null)
                .toList();
    }

    @GetMapping("/{productNumber}")
    public ProductView getOne(
            @PathVariable("productNumber") String productNumber) {

        return repository.findById(productNumber)
                .filter(view -> view.getName() != null
                        && view.getPrice() != null)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Product not found"));
    }
}