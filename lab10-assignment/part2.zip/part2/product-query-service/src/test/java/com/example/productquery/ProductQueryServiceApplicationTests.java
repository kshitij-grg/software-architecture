package com.example.productquery;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductQueryServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
