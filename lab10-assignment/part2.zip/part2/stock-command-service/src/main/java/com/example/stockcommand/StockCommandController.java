package com.example.stockcommand;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

@RestController
@RequestMapping("/stocks")
public class StockCommandController {

    private final StockRepository repository;
    private final StockEventPublisher publisher;

    public StockCommandController(
            StockRepository repository,
            StockEventPublisher publisher) {

        this.repository = repository;
        this.publisher = publisher;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Stock add(@RequestBody Stock stock) {
        if (stock.getProductNumber() == null
                || stock.getProductNumber().isBlank()
                || stock.getQuantity() < 0) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Product number is required and quantity cannot be negative");
        }

        if (repository.existsById(stock.getProductNumber())) {
            throw new ResponseStatusException(
                    HttpStatus.CONFLICT, "Stock record already exists");
        }

        Stock saved = repository.insert(stock);
        publisher.publish("STOCK_UPDATED", saved);
        return saved;
    }

    @PutMapping("/{productNumber}")
    public Stock update(
            @PathVariable("productNumber") String productNumber,
            @RequestBody Stock stock) {

        if (stock.getQuantity() < 0) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST, "Quantity cannot be negative");
        }

        Stock existing = repository.findById(productNumber)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Stock record not found"));

        existing.setQuantity(stock.getQuantity());

        Stock saved = repository.save(existing);
        publisher.publish("STOCK_UPDATED", saved);
        return saved;
    }

    @DeleteMapping("/{productNumber}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(
            @PathVariable("productNumber") String productNumber) {

        Stock existing = repository.findById(productNumber)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Stock record not found"));

        repository.deleteById(productNumber);
        publisher.publish("STOCK_DELETED", existing);
    }
}