package com.example.stockcommand;

import com.example.events.ProductEvent;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.stereotype.Component;

@Component
public class StockEventPublisher {

    private final RabbitTemplate rabbitTemplate;

    public StockEventPublisher(RabbitTemplate rabbitTemplate) {
        this.rabbitTemplate = rabbitTemplate;
    }

    public void publish(String eventType, Stock stock) {
        ProductEvent event = new ProductEvent(
                eventType,
                stock.getProductNumber(),
                null,
                null,
                stock.getQuantity()
        );

        rabbitTemplate.convertAndSend(RabbitConfig.QUEUE, event);
    }
}