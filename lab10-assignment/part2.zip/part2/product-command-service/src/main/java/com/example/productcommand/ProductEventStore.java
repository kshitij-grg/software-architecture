package com.example.productcommand;

import java.util.List;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface ProductEventStore
        extends MongoRepository<StoredProductEvent, String> {

    List<StoredProductEvent>
        findByProductNumberOrderBySequenceAsc(String productNumber);
}