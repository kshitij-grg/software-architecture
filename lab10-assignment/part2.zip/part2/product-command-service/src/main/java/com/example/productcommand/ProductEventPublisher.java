package com.example.productcommand;

import com.example.events.ProductEvent;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.stereotype.Component;

@Component
public class ProductEventPublisher {

    private final RabbitTemplate rabbitTemplate;

    public ProductEventPublisher(RabbitTemplate rabbitTemplate) {
        this.rabbitTemplate = rabbitTemplate;
    }

    public void publish(String eventType, Product product) {
        ProductEvent event = new ProductEvent(
                eventType,
                product.getProductNumber(),
                product.getName(),
                product.getPrice(),
                null
        );

        rabbitTemplate.convertAndSend(RabbitConfig.QUEUE, event);
    }
}