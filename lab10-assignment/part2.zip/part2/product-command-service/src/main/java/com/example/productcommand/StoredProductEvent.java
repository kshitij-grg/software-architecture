package com.example.productcommand;

import java.math.BigDecimal;
import java.time.Instant;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "product_events")
public record StoredProductEvent(
        @Id String id,
        String productNumber,
        long sequence,
        String eventType,
        String name,
        BigDecimal price,
        Instant occurredAt
) {
}