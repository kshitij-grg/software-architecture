package com.example.events;

import java.math.BigDecimal;

public record ProductEvent(
        String eventType,
        String productNumber,
        String name,
        BigDecimal price,
        Integer quantity
) {
}