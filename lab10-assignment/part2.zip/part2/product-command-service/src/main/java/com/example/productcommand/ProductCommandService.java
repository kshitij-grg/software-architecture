package com.example.productcommand;

import java.time.Instant;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class ProductCommandService {

    private final ProductEventStore eventStore;
    private final ProductEventPublisher publisher;

    public ProductCommandService(
            ProductEventStore eventStore,
            ProductEventPublisher publisher) {

        this.eventStore = eventStore;
        this.publisher = publisher;
    }

    public synchronized Product add(Product product) {
        validate(product);

        List<StoredProductEvent> history = history(
                product.getProductNumber());

        if (replay(history) != null) {
            throw new ResponseStatusException(
                    HttpStatus.CONFLICT, "Product already exists");
        }

        append("PRODUCT_CREATED", product, history);
        return product;
    }

    public synchronized Product update(
            String productNumber, Product changes) {

        List<StoredProductEvent> history = history(productNumber);
        Product current = requireProduct(history);

        current.setName(changes.getName());
        current.setPrice(changes.getPrice());
        validate(current);

        append("PRODUCT_UPDATED", current, history);
        return current;
    }

    public synchronized void delete(String productNumber) {
        List<StoredProductEvent> history = history(productNumber);
        Product current = requireProduct(history);

        append("PRODUCT_DELETED", current, history);
    }

    private List<StoredProductEvent> history(String productNumber) {
        return eventStore
                .findByProductNumberOrderBySequenceAsc(productNumber);
    }

    private Product replay(List<StoredProductEvent> history) {
        Product current = null;

        for (StoredProductEvent event : history) {
            switch (event.eventType()) {
                case "PRODUCT_CREATED", "PRODUCT_UPDATED" ->
                        current = new Product(
                                event.productNumber(),
                                event.name(),
                                event.price());

                case "PRODUCT_DELETED" -> current = null;

                default -> throw new IllegalStateException(
                        "Unknown event type: " + event.eventType());
            }
        }

        return current;
    }

    private Product requireProduct(List<StoredProductEvent> history) {
        Product current = replay(history);

        if (current == null) {
            throw new ResponseStatusException(
                    HttpStatus.NOT_FOUND, "Product not found");
        }

        return current;
    }

    private void append(
            String eventType,
            Product product,
            List<StoredProductEvent> history) {

        long sequence = history.isEmpty()
                ? 1
                : history.get(history.size() - 1).sequence() + 1;

        StoredProductEvent event = new StoredProductEvent(
                product.getProductNumber() + ":" + sequence,
                product.getProductNumber(),
                sequence,
                eventType,
                product.getName(),
                product.getPrice(),
                Instant.now()
        );

        eventStore.insert(event);
        publisher.publish(eventType, product);
    }

    private void validate(Product product) {
        if (product.getProductNumber() == null
                || product.getProductNumber().isBlank()
                || product.getName() == null
                || product.getName().isBlank()
                || product.getPrice() == null
                || product.getPrice().signum() < 0) {

            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Product number, name, and non-negative price are required");
        }
    }
}