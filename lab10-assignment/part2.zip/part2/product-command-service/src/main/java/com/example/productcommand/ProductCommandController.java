package com.example.productcommand;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/products")
public class ProductCommandController {

    private final ProductCommandService service;

    public ProductCommandController(ProductCommandService service) {
        this.service = service;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Product add(@RequestBody Product product) {
        return service.add(product);
    }

    @PutMapping("/{productNumber}")
    public Product update(
            @PathVariable("productNumber") String productNumber,
            @RequestBody Product product) {

        return service.update(productNumber, product);
    }

    @DeleteMapping("/{productNumber}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(
            @PathVariable("productNumber") String productNumber) {

        service.delete(productNumber);
    }
}