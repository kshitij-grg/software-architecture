package com.example.productcommand;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

@RestController
@RequestMapping("/products")
public class ProductCommandController {

    private final ProductRepository repository;
    private final ProductEventPublisher publisher;

    public ProductCommandController(
            ProductRepository repository,
            ProductEventPublisher publisher) {

        this.repository = repository;
        this.publisher = publisher;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Product add(@RequestBody Product product) {
        if (product.getProductNumber() == null
                || product.getProductNumber().isBlank()) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST, "Product number is required");
        }

        if (repository.existsById(product.getProductNumber())) {
            throw new ResponseStatusException(
                    HttpStatus.CONFLICT, "Product already exists");
        }

        Product saved = repository.insert(product);
        publisher.publish("PRODUCT_CREATED", saved);
        return saved;
    }

    @PutMapping("/{productNumber}")
    public Product update(
            @PathVariable("productNumber") String productNumber,
            @RequestBody Product product) {

        Product existing = repository.findById(productNumber)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Product not found"));

        existing.setName(product.getName());
        existing.setPrice(product.getPrice());

        Product saved = repository.save(existing);
        publisher.publish("PRODUCT_UPDATED", saved);
        return saved;
    }

    @DeleteMapping("/{productNumber}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(
            @PathVariable("productNumber") String productNumber) {

        Product existing = repository.findById(productNumber)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Product not found"));

        repository.deleteById(productNumber);
        publisher.publish("PRODUCT_DELETED", existing);
    }
}